package com.example.androidtask

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class NumberAdapter(private val numbers: List<Int>, private val currentRule: Rule) :
    RecyclerView.Adapter<NumberAdapter.NumberViewHolder>() {

    class NumberViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val numberTextView: TextView = itemView.findViewById(R.id.numberTextView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NumberViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_number, parent, false)
        return NumberViewHolder(view)
    }

    override fun onBindViewHolder(holder: NumberViewHolder, position: Int) {
        val number = numbers[position]
        holder.numberTextView.text = number.toString()

        holder.numberTextView.setBackgroundColor(
            if (Rule.isNumberHighlighted(currentRule,number)) {
                android.graphics.Color.YELLOW // Highlight color
            } else {
                android.graphics.Color.TRANSPARENT // Default color
            }
        )
    }

    override fun getItemCount(): Int {
        return numbers.size
    }
}